import { Project } from '../types';

export const projects: Project[] = [
  {
    id: 'project-1',
    title: 'StudBud: AI Study Planner',
    description: 'A Generative AI-based personalized study planner utilizing Python, TensorFlow, and BERT for creating customized learning schedules and study recommendations.',
    image: 'https://images.pexels.com/photos/5905700/pexels-photo-5905700.jpeg',
    tags: ['Python', 'TensorFlow', 'BERT', 'AI'],
    demoLink: 'https://github.com/ammulu-n/studbud',
    codeLink: 'https://github.com/ammulu-n/studbud'
  },
  {
    id: 'project-2',
    title: 'Blockchain Document Verification',
    description: 'A secure document verification system using blockchain technology to ensure authenticity and prevent tampering of important documents.',
    image: 'https://images.pexels.com/photos/8370752/pexels-photo-8370752.jpeg',
    tags: ['Blockchain', 'Smart Contracts', 'Web3', 'Security'],
    demoLink: 'https://github.com/ammulu-n/blockchain-verification',
    codeLink: 'https://github.com/ammulu-n/blockchain-verification'
  },
  {
    id: 'project-3',
    title: 'E-commerce Price Negotiation Chatbot',
    description: 'An intelligent chatbot system for e-commerce platforms that enables automated price negotiations between buyers and sellers.',
    image: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg',
    tags: ['AI', 'NLP', 'Python', 'E-commerce'],
    demoLink: 'https://github.com/ammulu-n/negotiation-bot',
    codeLink: 'https://github.com/ammulu-n/negotiation-bot'
  },
  {
    id: 'project-4',
    title: 'IoT Cybersecurity Analysis',
    description: 'Research project analyzing cybersecurity risks in IoT ecosystems, including vulnerability assessment and security recommendations.',
    image: 'https://images.pexels.com/photos/1714208/pexels-photo-1714208.jpeg',
    tags: ['IoT', 'Cybersecurity', 'Research', 'Analysis'],
    demoLink: 'https://github.com/ammulu-n/iot-security',
    codeLink: 'https://github.com/ammulu-n/iot-security'
  }
];