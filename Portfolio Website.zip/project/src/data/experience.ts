import { Experience } from '../types';

export const experiences: Experience[] = [
  {
    title: 'ServiceNow Intern',
    company: 'ServiceNow',
    location: 'Remote',
    startDate: '2023',
    endDate: '2023',
    description: [
      'Gained hands-on experience with ServiceNow platform development',
      'Participated in workflow automation and system integration projects',
      'Collaborated with team members on platform customization'
    ]
  },
  {
    title: 'Cybersecurity Intern',
    company: 'VaultofCodes',
    location: 'Remote',
    startDate: '2023',
    endDate: '2023',
    description: [
      'Worked on cybersecurity projects and vulnerability assessments',
      'Learned about security best practices and threat detection',
      'Participated in security audits and risk assessments'
    ]
  },
  {
    title: 'Full Stack Development Intern',
    company: 'CODTECH IT SOLUTIONS PVT.LTD',
    location: 'Remote',
    startDate: '2023',
    endDate: '2023',
    description: [
      'Developed full-stack applications using modern technologies',
      'Worked with React.js for frontend and Node.js for backend development',
      'Collaborated with team members on project development and deployment'
    ]
  },
  {
    title: 'IT Intern',
    company: 'Micro IT',
    location: 'Remote',
    startDate: '2023',
    endDate: '2023',
    description: [
      'Gained practical experience in IT operations and management',
      'Worked on various technical projects and system maintenance',
      'Developed problem-solving skills in IT environment'
    ]
  }
];