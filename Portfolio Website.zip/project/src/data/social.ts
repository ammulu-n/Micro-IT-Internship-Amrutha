import { SocialLink } from '../types';

export const socialLinks: SocialLink[] = [
  {
    name: 'GitHub',
    url: 'https://github.com/ammulu-n',
    icon: 'Github'
  },
  {
    name: 'LinkedIn',
    url: 'https://www.linkedin.com/in/amrutha-thanniru-1366a4294',
    icon: 'Linkedin'
  },
  {
    name: 'Email',
    url: 'mailto:manikantathanniru111@gmail.com',
    icon: 'Mail'
  },
  {
    name: 'Phone',
    url: 'tel:+919959495461',
    icon: 'Phone'
  }
];