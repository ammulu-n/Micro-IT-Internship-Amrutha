import { Education } from '../types';

export const education: Education[] = [
  {
    degree: 'B.Tech in Computer Science and Engineering (Cybersecurity)',
    institution: 'Malla Reddy Engineering College for Women (Autonomous)',
    location: 'Hyderabad',
    startYear: 2022,
    endYear: 2026
  }
];