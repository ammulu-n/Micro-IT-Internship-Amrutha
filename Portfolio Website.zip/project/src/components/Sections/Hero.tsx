import React from 'react';
import { ArrowDown } from 'lucide-react';
import Button from '../UI/Button';

const Hero = () => {
  const scrollToAbout = () => {
    document.querySelector('#about')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section 
      id="home" 
      className="relative min-h-screen flex items-center pt-16"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-white to-blue-50 dark:from-gray-900 dark:to-gray-800 -z-10"></div>
      
      <div className="absolute top-20 right-10 w-64 h-64 bg-blue-400 dark:bg-blue-600 rounded-full opacity-10 animate-pulse"></div>
      <div className="absolute bottom-20 left-10 w-40 h-40 bg-teal-400 dark:bg-teal-600 rounded-full opacity-10 animate-pulse delay-700"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div 
            className="text-center"
            data-aos="fade-up"
            data-aos-duration="1000"
          >
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
              <span className="block">Hi, I'm <span className="text-blue-600 dark:text-blue-400">Amrutha Thanniru</span></span>
              <span className="block mt-2">Cybersecurity Student & Developer</span>
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-2xl mx-auto">
              A passionate B.Tech student specializing in Cybersecurity, with expertise in full-stack development,
              AI/ML, and a drive for creating innovative solutions.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button onClick={scrollToAbout} size="lg">
                View My Work
              </Button>
              <Button variant="outline" size="lg" onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}>
                Contact Me
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex flex-col items-center animate-bounce">
        <span className="text-sm text-gray-600 dark:text-gray-400 mb-2">Scroll Down</span>
        <ArrowDown className="text-gray-600 dark:text-gray-400" size={20} />
      </div>
    </section>
  );
};

export default Hero;