import React, { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  hoverEffect?: boolean;
}

const Card: React.FC<CardProps> = ({ 
  children, 
  className = '', 
  hoverEffect = false 
}) => {
  const baseStyles = 'bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden';
  const hoverStyles = hoverEffect ? 'transition-all duration-300 hover:shadow-xl hover:-translate-y-1' : '';
  
  return (
    <div className={`${baseStyles} ${hoverStyles} ${className}`}>
      {children}
    </div>
  );
};

export default Card;