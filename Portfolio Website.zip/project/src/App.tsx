import React, { useEffect } from 'react';
import Layout from './components/Layout/Layout';
import Hero from './components/Sections/Hero';
import About from './components/Sections/About';
import Projects from './components/Sections/Projects';
import Contact from './components/Sections/Contact';
import { ThemeProvider } from './hooks/useTheme';

function App() {
  useEffect(() => {
    // Update title
    document.title = 'Your Name | Portfolio';
  }, []);

  return (
    <ThemeProvider>
      <Layout>
        <Hero />
        <About />
        <Projects />
        <Contact />
      </Layout>
    </ThemeProvider>
  );
}

export default App;