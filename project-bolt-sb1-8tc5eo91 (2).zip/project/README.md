# ShopHub - Modern E-commerce Store

A full-featured e-commerce application built with React, TypeScript, and Tailwind CSS. This project demonstrates modern web development practices and includes all essential e-commerce functionality.

## 🚀 Features

### Core E-commerce Features
- **Product Catalog**: Browse products with filtering and sorting
- **Product Details**: Detailed product pages with image galleries
- **Shopping Cart**: Add, remove, and manage cart items
- **Wishlist**: Save products for later
- **Checkout Process**: Complete order flow with form validation
- **Responsive Design**: Mobile-first responsive layout

### Technical Features
- **React 18** with TypeScript
- **React Router** for navigation
- **Context API** for state management
- **Tailwind CSS** for styling
- **Lucide React** for icons
- **Modern ES6+** JavaScript features

### User Experience
- **Dark/Light Mode** support
- **Smooth Animations** and transitions
- **Loading States** and feedback
- **Form Validation** with error handling
- **Search Functionality**
- **Category Filtering**
- **Price Range Filtering**

## 📁 Project Structure

```
src/
├── components/
│   ├── Layout/
│   │   ├── Header.tsx
│   │   └── Footer.tsx
│   └── UI/
│       ├── ProductCard.tsx
│       └── ...
├── context/
│   ├── CartContext.tsx
│   └── WishlistContext.tsx
├── data/
│   └── products.ts
├── pages/
│   ├── Home.tsx
│   ├── Products.tsx
│   ├── ProductDetail.tsx
│   ├── Cart.tsx
│   ├── Wishlist.tsx
│   ├── Checkout.tsx
│   ├── About.tsx
│   └── Contact.tsx
├── types/
│   └── index.ts
└── App.tsx
```

## 🛠️ Installation & Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/ammulu-n/ecommerce-store.git
   cd ecommerce-store
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start development server**
   ```bash
   npm run dev
   ```

4. **Build for production**
   ```bash
   npm run build
   ```

## 🎯 Key Components

### State Management
- **CartContext**: Manages shopping cart state and operations
- **WishlistContext**: Handles wishlist functionality

### Pages
- **Home**: Hero section, featured products, categories
- **Products**: Product listing with filters and search
- **ProductDetail**: Individual product information
- **Cart**: Shopping cart management
- **Checkout**: Order completion flow
- **About**: Company information
- **Contact**: Contact form and information

### UI Components
- **ProductCard**: Reusable product display component
- **Header**: Navigation with cart/wishlist indicators
- **Footer**: Site links and information

## 🔧 Technologies Used

- **Frontend Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS
- **Routing**: React Router DOM
- **Icons**: Lucide React
- **Build Tool**: Vite
- **Code Quality**: ESLint, TypeScript

## 📱 Responsive Design

The application is fully responsive and optimized for:
- **Mobile devices** (320px and up)
- **Tablets** (768px and up)
- **Desktop** (1024px and up)
- **Large screens** (1280px and up)

## 🎨 Design Features

- **Modern UI/UX** with clean design
- **Consistent color scheme** with blue primary colors
- **Smooth animations** and hover effects
- **Loading states** for better user feedback
- **Form validation** with error messages
- **Accessible** design following best practices

## 🚀 Deployment

This project can be deployed to various platforms:

### Netlify
1. Build the project: `npm run build`
2. Deploy the `dist` folder to Netlify

### Vercel
1. Connect your GitHub repository
2. Vercel will automatically build and deploy

### GitHub Pages
1. Install gh-pages: `npm install --save-dev gh-pages`
2. Add deploy script to package.json
3. Run: `npm run deploy`

## 📈 Future Enhancements

- **User Authentication**: Login/register functionality
- **Payment Integration**: Stripe/PayPal integration
- **Product Reviews**: Customer review system
- **Admin Panel**: Product management interface
- **Search Enhancement**: Advanced search with filters
- **Recommendations**: AI-powered product suggestions
- **Multi-language**: Internationalization support

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature-name`
3. Commit changes: `git commit -m 'Add feature'`
4. Push to branch: `git push origin feature-name`
5. Submit a pull request

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 👨‍💻 Author

**Amrutha Thanniru**
- GitHub: [@ammulu-n](https://github.com/ammulu-n)
- LinkedIn: [Amrutha Thanniru](https://www.linkedin.com/in/amrutha-thanniru-1366a4294)
- Email: manikantathanniru111@gmail.com

## 🙏 Acknowledgments

- **Pexels** for providing high-quality stock images
- **Lucide** for the beautiful icon set
- **Tailwind CSS** for the utility-first CSS framework
- **React Team** for the amazing framework

---

Built with ❤️ by Amrutha Thanniru