import React from 'react';

interface SkillBarProps {
  name: string;
  level: number; // 1-5
}

const SkillBar: React.FC<SkillBarProps> = ({ name, level }) => {
  // Calculate percentage based on level (1-5)
  const percentage = (level / 5) * 100;
  
  return (
    <div className="mb-4">
      <div className="flex justify-between items-center mb-1">
        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{name}</span>
        <span className="text-xs font-medium text-gray-500 dark:text-gray-400">{level}/5</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
        <div 
          className="bg-blue-600 dark:bg-blue-500 h-2.5 rounded-full transition-all duration-1000 ease-out"
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
    </div>
  );
};

export default SkillBar;