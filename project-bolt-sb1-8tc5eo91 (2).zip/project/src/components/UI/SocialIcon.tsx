import React from 'react';
import * as LucideIcons from 'lucide-react';

interface SocialIconProps {
  icon: string;
  size?: number;
}

const SocialIcon: React.FC<SocialIconProps> = ({ icon, size = 20 }) => {
  // Get the icon component from lucide-react
  const IconComponent = LucideIcons[icon as keyof typeof LucideIcons];
  
  // If the icon doesn't exist, return null or a default icon
  if (!IconComponent) {
    return <LucideIcons.Link size={size} />;
  }
  
  return <IconComponent size={size} />;
};

export default SocialIcon;