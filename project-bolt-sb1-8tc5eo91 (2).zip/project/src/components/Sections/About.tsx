import React, { useState } from 'react';
import Section from '../UI/Section';
import SkillBar from '../UI/SkillBar';
import Card from '../UI/Card';
import { skills } from '../../data/skills';
import { experiences } from '../../data/experience';
import { education } from '../../data/education';
import { Briefcase, GraduationCap, Code } from 'lucide-react';

const About = () => {
  const [activeTab, setActiveTab] = useState<'experience' | 'education' | 'skills'>('experience');
  const [activeSkillCategory, setActiveSkillCategory] = useState<string>('all');

  const filteredSkills = activeSkillCategory === 'all'
    ? skills
    : skills.filter(skill => skill.category === activeSkillCategory);

  return (
    <Section
      id="about"
      title="About Me"
      subtitle="Here you can find information about my academic journey, skills, and experience."
      className="bg-gray-50 dark:bg-gray-900"
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <Card className="p-6 h-full">
            <div className="flex flex-col items-center">
              <div className="w-48 h-48 rounded-full overflow-hidden mb-6 border-4 border-white dark:border-gray-800 shadow-lg">
                <img 
                  src="https://images.pexels.com/photos/3861958/pexels-photo-3861958.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                  alt="Profile" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Amrutha Thanniru</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">Cybersecurity Student</p>
              <p className="text-center text-gray-600 dark:text-gray-400 mb-6">
                I am a B.Tech student specializing in Cybersecurity at Malla Reddy Engineering College for Women. 
                I am passionate about technology, particularly cybersecurity, AI, ML, and full-stack development. 
                My goal is to build innovative solutions while contributing to both academic and professional growth.
              </p>
              <div className="grid grid-cols-2 gap-3 w-full">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">5+</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Projects</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">5+</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Internships</div>
                </div>
              </div>
            </div>
          </Card>
        </div>
        
        <div className="lg:col-span-2">
          <Card className="overflow-hidden h-full">
            <div className="border-b border-gray-200 dark:border-gray-700">
              <nav className="flex" aria-label="Tabs">
                <button
                  onClick={() => setActiveTab('experience')}
                  className={`flex items-center py-4 px-6 font-medium text-sm ${
                    activeTab === 'experience'
                      ? 'border-b-2 border-blue-500 text-blue-600 dark:text-blue-400'
                      : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
                  }`}
                >
                  <Briefcase className="mr-2" size={18} />
                  Experience
                </button>
                <button
                  onClick={() => setActiveTab('education')}
                  className={`flex items-center py-4 px-6 font-medium text-sm ${
                    activeTab === 'education'
                      ? 'border-b-2 border-blue-500 text-blue-600 dark:text-blue-400'
                      : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
                  }`}
                >
                  <GraduationCap className="mr-2" size={18} />
                  Education
                </button>
                <button
                  onClick={() => setActiveTab('skills')}
                  className={`flex items-center py-4 px-6 font-medium text-sm ${
                    activeTab === 'skills'
                      ? 'border-b-2 border-blue-500 text-blue-600 dark:text-blue-400'
                      : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
                  }`}
                >
                  <Code className="mr-2" size={18} />
                  Skills
                </button>
              </nav>
            </div>
            
            <div className="p-6">
              {activeTab === 'experience' && (
                <div>
                  {experiences.map((exp, index) => (
                    <div key={index} className={`${index !== 0 ? 'mt-8' : ''}`}>
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h4 className="text-lg font-semibold text-gray-900 dark:text-white">{exp.title}</h4>
                          <p className="text-gray-600 dark:text-gray-400">{exp.company} - {exp.location}</p>
                        </div>
                        <span className="text-sm text-gray-500 dark:text-gray-400 whitespace-nowrap">
                          {exp.startDate} - {exp.endDate}
                        </span>
                      </div>
                      <ul className="mt-2 list-disc list-inside text-gray-600 dark:text-gray-400">
                        {exp.description.map((item, i) => (
                          <li key={i} className="mb-1">{item}</li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              )}
              
              {activeTab === 'education' && (
                <div className="space-y-6">
                  {education.map((edu, index) => (
                    <div key={index} className="flex items-start">
                      <div className="flex-shrink-0 mt-1">
                        <GraduationCap className="text-blue-500 dark:text-blue-400" size={20} />
                      </div>
                      <div className="ml-4">
                        <h4 className="text-lg font-semibold text-gray-900 dark:text-white">{edu.degree}</h4>
                        <p className="text-gray-600 dark:text-gray-400">{edu.institution}, {edu.location}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                          {edu.startYear} - {edu.endYear}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              {activeTab === 'skills' && (
                <>
                  <div className="mb-6">
                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() => setActiveSkillCategory('all')}
                        className={`px-3 py-1 text-sm rounded-full ${
                          activeSkillCategory === 'all'
                            ? 'bg-blue-600 text-white dark:bg-blue-700'
                            : 'bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300'
                        }`}
                      >
                        All
                      </button>
                      <button
                        onClick={() => setActiveSkillCategory('frontend')}
                        className={`px-3 py-1 text-sm rounded-full ${
                          activeSkillCategory === 'frontend'
                            ? 'bg-blue-600 text-white dark:bg-blue-700'
                            : 'bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300'
                        }`}
                      >
                        Frontend
                      </button>
                      <button
                        onClick={() => setActiveSkillCategory('backend')}
                        className={`px-3 py-1 text-sm rounded-full ${
                          activeSkillCategory === 'backend'
                            ? 'bg-blue-600 text-white dark:bg-blue-700'
                            : 'bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300'
                        }`}
                      >
                        Backend
                      </button>
                      <button
                        onClick={() => setActiveSkillCategory('other')}
                        className={`px-3 py-1 text-sm rounded-full ${
                          activeSkillCategory === 'other'
                            ? 'bg-blue-600 text-white dark:bg-blue-700'
                            : 'bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300'
                        }`}
                      >
                        Other
                      </button>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                    {filteredSkills.map((skill) => (
                      <SkillBar key={skill.name} name={skill.name} level={skill.level} />
                    ))}
                  </div>
                </>
              )}
            </div>
          </Card>
        </div>
      </div>
    </Section>
  );
};

export default About;