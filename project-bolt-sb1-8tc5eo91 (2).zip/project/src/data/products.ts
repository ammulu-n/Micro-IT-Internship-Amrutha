import { Product } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Premium Wireless Headphones',
    price: 299.99,
    originalPrice: 399.99,
    image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg',
    category: 'Electronics',
    description: 'High-quality wireless headphones with noise cancellation and premium sound quality.',
    features: ['Active Noise Cancellation', '30-hour battery life', 'Premium sound quality', 'Comfortable fit'],
    rating: 4.8,
    reviews: 124,
    inStock: true,
    discount: 25,
    isFeatured: true
  },
  {
    id: '2',
    name: 'Smart Fitness Watch',
    price: 199.99,
    originalPrice: 249.99,
    image: 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg',
    category: 'Electronics',
    description: 'Advanced fitness tracking with heart rate monitoring and GPS.',
    features: ['Heart rate monitoring', 'GPS tracking', 'Water resistant', '7-day battery'],
    rating: 4.6,
    reviews: 89,
    inStock: true,
    discount: 20,
    isNew: true
  },
  {
    id: '3',
    name: 'Organic Cotton T-Shirt',
    price: 29.99,
    image: 'https://images.pexels.com/photos/996329/pexels-photo-996329.jpeg',
    category: 'Clothing',
    description: 'Comfortable organic cotton t-shirt in various colors.',
    features: ['100% organic cotton', 'Soft and comfortable', 'Available in multiple colors', 'Sustainable'],
    rating: 4.4,
    reviews: 67,
    inStock: true,
    isFeatured: true
  },
  {
    id: '4',
    name: 'Professional Camera',
    price: 899.99,
    originalPrice: 1199.99,
    image: 'https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg',
    category: 'Electronics',
    description: 'Professional DSLR camera with advanced features for photography enthusiasts.',
    features: ['24MP sensor', '4K video recording', 'Weather sealed', 'Dual card slots'],
    rating: 4.9,
    reviews: 156,
    inStock: true,
    discount: 25
  },
  {
    id: '5',
    name: 'Luxury Handbag',
    price: 159.99,
    image: 'https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg',
    category: 'Fashion',
    description: 'Elegant leather handbag perfect for any occasion.',
    features: ['Genuine leather', 'Multiple compartments', 'Adjustable strap', 'Premium hardware'],
    rating: 4.7,
    reviews: 92,
    inStock: true,
    isNew: true
  },
  {
    id: '6',
    name: 'Gaming Laptop',
    price: 1299.99,
    originalPrice: 1599.99,
    image: 'https://images.pexels.com/photos/18105/pexels-photo.jpg',
    category: 'Electronics',
    description: 'High-performance gaming laptop with latest graphics and processor.',
    features: ['RTX 4060 Graphics', '16GB RAM', '1TB SSD', '144Hz display'],
    rating: 4.8,
    reviews: 203,
    inStock: true,
    discount: 19,
    isFeatured: true
  },
  {
    id: '7',
    name: 'Wireless Earbuds',
    price: 79.99,
    originalPrice: 99.99,
    image: 'https://images.pexels.com/photos/8534088/pexels-photo-8534088.jpeg',
    category: 'Electronics',
    description: 'Compact wireless earbuds with excellent sound quality.',
    features: ['True wireless', 'Touch controls', '6-hour battery', 'Charging case'],
    rating: 4.3,
    reviews: 78,
    inStock: true,
    discount: 20
  },
  {
    id: '8',
    name: 'Running Shoes',
    price: 119.99,
    image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg',
    category: 'Sports',
    description: 'Comfortable running shoes with advanced cushioning technology.',
    features: ['Advanced cushioning', 'Breathable mesh', 'Durable outsole', 'Lightweight design'],
    rating: 4.5,
    reviews: 134,
    inStock: true,
    isNew: true
  }
];

export const categories = [
  { id: '1', name: 'Electronics', image: 'https://images.pexels.com/photos/356056/pexels-photo-356056.jpeg', productCount: 15 },
  { id: '2', name: 'Clothing', image: 'https://images.pexels.com/photos/996329/pexels-photo-996329.jpeg', productCount: 23 },
  { id: '3', name: 'Fashion', image: 'https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg', productCount: 18 },
  { id: '4', name: 'Sports', image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg', productCount: 12 }
];