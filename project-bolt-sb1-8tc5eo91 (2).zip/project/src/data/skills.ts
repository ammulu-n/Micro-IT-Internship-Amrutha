import { Skill } from '../types';

export const skills: Skill[] = [
  { name: 'Python', level: 5, category: 'backend' },
  { name: 'Java', level: 3, category: 'backend' },
  { name: 'C', level: 5, category: 'backend' },
  { name: 'JavaScript', level: 4, category: 'frontend' },
  { name: 'React', level: 3, category: 'frontend' },
  { name: 'Node.js', level: 3, category: 'backend' },
  { name: 'HTML5', level: 4, category: 'frontend' },
  { name: 'CSS3', level: 4, category: 'frontend' },
  { name: 'Git & GitHub', level: 3, category: 'other' },
  { name: 'Machine Learning', level: 3, category: 'other' },
  { name: 'Cybersecurity', level: 4, category: 'other' },
  { name: 'Problem Solving', level: 4, category: 'other' }
];